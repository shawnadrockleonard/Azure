<#
    .SYNOPSIS
        Creates a Windows 10 Store-ready APPX package from an application's command-line installer
    .DESCRIPTION
        This converter depends on an optional Windows feature being enabled. Please refer to machine setup instructions to ensure you have enabled it.

        NOTE: Your installer must be able to run unattended/silently. Sequencing an attended installer, or one with any UI is unsupported at this time.
    .PARAMETER Setup
        Use this flag to run DesktopAppConverter in setup mode. Setup mode supports expanding a provided base image.
    .PARAMETER BaseImage
        The path to an unexpanded base image. This param is needed if -Setup is specified.
    .PARAMETER NatSubnetPrefix
        [optional] Prefix value to be used for the Nat instance. Typically you would want to change this only if your host
        machine is attached to the same subnet range as the Converter's NetNat. You can query the current Converter NetNat config using
        Get-NetNat cmdlet.
    .PARAMETER Installer
        The path to the installer for your application - must be able to run unattended/silently
    .PARAMETER InstallerArguments
        [optional] A comma-separated list or string of arguments to force your installer to run unattended/silently. This parameter is optional if your installer is an msi.
        In order to get a log from your installer, you must supply the logging argument for the installer here and use the path "<log_folder>", which is a token that the converter will replace with the appropriate path.

        NOTE: The unattended/silent flags and log arguments will vary between installer technologies

        An example usage for this parameter: -InstallerArguments "/silent /log <log_folder>\install.log"
        Another example that doesn't produce a log file may look like: -InstallerArguments "/quiet", "/norestart"

        Again, you must literally direct any logs to the token path "<log_folder>" if you want the converter to capture it and put it in the final log folder
    .PARAMETER InstallerValidExitCodes
        [optional] A comma-separated list of exit codes that indicate your installer ran successfully (for example: 0, 1234, 5678) . By default this is 0 for non-msi, and 0, 1641, 3010 for msi.
    .PARAMETER Destination
        The desired destination for the converter's appx output - DesktopAppConverter can create this location if it doesn't already exist
    .PARAMETER PackageName
        The name of your Universal Windows App package
    .PARAMETER Publisher
        The publisher of your Universal Windows App package
    .PARAMETER Version
        The version number for your Universal Windows App package
    .PARAMETER AppInstallPath
        The full path to your application's root folder for the installed files if it were installed (eg "C:\Program Files (x86)\MyApp")
    .PARAMETER AppExecutable
        [optional] The full path to your application's main executable if it were installed (it doesn't have to be) (eg "C:\Program Files (x86)\MyApp\MyApp.exe")
    .PARAMETER AppFileTypes
        [optional] A comma-separated list of file types which the application will be associated with (eg. ".txt, .doc", without the quotes).
    .PARAMETER AppProtocols
        [optional] A comma-separated list of protocols which the application will be associated with (eg. "http, mailto", without the quotes).
    .PARAMETER AppId
        [optional] Specifies a value to set Application Id to in the appx manifest. If it is not specified, it will be set to the value passed in for PackageName
    .PARAMETER AppDisplayName
        [optional] Specifies a value to set Application Display Name to in the appx manifest. If it is not specified, it will be set to the value passed in for PackageName
    .PARAMETER AppDescription
        [optional] Specifies a value to set Application Description to in the appx manifest. If it is not specified, it will be set to the value passed in for PackageName
    .PARAMETER PackageDisplayName
        [optional] Specifies a value to set Package Display Name to in the appx manifest. If it is not specified, it will be set to the value passed in for PackageName
    .PARAMETER PackagePublisherDisplayName
        [optional] Specifies a value to set Package Publisher Display Name to in the appx manifest. If it is not specified, it will be set to the value passed in for Publisher
    .PARAMETER ExpandedBaseImage
        [optional] The path to an already expanded base image. Use this if you have multiple expanded base images on your system, and would like to use one other than the most recently created.
    .PARAMETER MakeAppx
        [optional] A switch that when present, tells this script to call MakeAppx on the output
    .PARAMETER LogFile
        [optional] Specifies a log file. If omitted, a log file temporary location will be created.
    .EXAMPLE
        .\DesktopAppConverter.ps1 -ExpandedBaseImage C:\Images\Client -Installer C:\MyInstallers\MyApp.msi -Destination C:\MyAppxFolder -PackageName "MyApp" -Publisher "CN=Microsoft" -Version 1.0.0.0 -AppExecutable "C:\Program Files\MyApp\MyApp.exe" -MakeAppx

        Sequence an msi, put the specified AppExecutable into the AppxManifest.xml for your app, and package everything into "MyApp.appx".

    .EXAMPLE
        .\DesktopAppConverter.ps1 -ExpandedBaseImage C:\Images\Client -Installer C:\MyInstallers\MyAppSetup.exe -InstallerArguments "/quiet","/norestart" -Destination C:\MyAppxFolder -PackageName "MyApp" -Publisher "CN=Microsoft" -Version 1.0.0.0 -Verbose

        Sequence a setup exe installer by providing silent flags (NOTE: Flags will vary based on your installer technology),
        and leave the output unpackaged (you can manually package using makeappx.exe). The "-Verbose" flag causes progress to be printed to console.
#>
[CmdletBinding(DefaultParameterSetName="Convert")]
Param(
    [Parameter(Mandatory=$True, ParameterSetName="Setup")]
    [switch]
    $Setup,

    [Parameter(Mandatory=$True, ParameterSetName="Setup")]
    [string]
    [ValidateNotNullOrEmpty()]
    $BaseImage,

    [Parameter(Mandatory=$False, ParameterSetName="Setup")]
    [string]
    $NatSubnetPrefix,

    [Parameter(Mandatory=$True, ParameterSetName="Convert")]
    [string]
    [ValidateNotNullOrEmpty()]
    $Installer,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string[]]
    $InstallerArguments,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [int[]]
    $InstallerValidExitCodes,

    [Parameter(Mandatory=$True, ParameterSetName="Convert")]
    [string]
    [ValidateNotNullOrEmpty()]
    $Destination,

    [Parameter(Mandatory=$True, ParameterSetName="Convert")]
    [string]
    [ValidateNotNullOrEmpty()]
    $PackageName,

    [Parameter(Mandatory=$True, ParameterSetName="Convert")]
    [string]
    [ValidateNotNullOrEmpty()]
    $Publisher,

    [Parameter(Mandatory=$True, ParameterSetName="Convert")]
    [version]
    [ValidateNotNull()]
    $Version,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string]
    [ValidateNotNull()]
    $AppInstallPath,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string]
    $AppExecutable,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string[]]
    $AppFileTypes,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string[]]
    $AppProtocols,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string]
    $AppId,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string]
    $AppDisplayName,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string]
    $AppDescription,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string]
    $PackageDisplayName,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string]
    $PackagePublisherDisplayName,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [string]
    $ExpandedBaseImage,

    [Parameter(Mandatory=$False, ParameterSetName="Convert")]
    [switch]
    $MakeAppx,

    [Parameter(Mandatory=$False)]
    [string]
    $LogFile
)

$ErrorActionPreference = "Stop"

$myLocation = (Split-Path (Get-Variable MyInvocation -Scope 0).Value.mycommand.path)

. (Join-Path $myLocation "converter_util\CWACLogger.ps1")
. (Join-Path $mylocation "converter_util\TempLocation.ps1")

$hostTempLocation = Create-TempLocation
$logDirectory = $null

if (!$LogFile)
{
    $logDirectory = (New-Item -Path (Join-Path $hostTempLocation "logs") -ItemType Directory -Force).FullName
    $LogFile = Join-Path $logDirectory "DesktopAppConverter.log"
}
else
{
    New-Item -Path $LogFile -ItemType File -Force > $null
    $logDirectory = (Get-Item $LogFile).DirectoryName
}

$logger = [CWACLogger]::new($LogFile, (Join-Path $myLocation "telemetry"))
$logger.LogDiag("Log files can be found in $logDirectory")

# Log version if this was an official build
$versionFile = (Join-path $myLocation "version.txt")
if (Test-Path $versionFile)
{
    $versionString = Get-Content $versionFile
    $logger.LogVersion($versionString)
}

try
{
    . (Join-Path $myLocation "converter_util\EnvironmentAssertions.ps1")
    $logger.NewLogSection("Checking Prerequisites", "CheckPrereq")

    Assert-MinimumWindowsVersion $logger

    if ($Setup)
    {
        $logger.NewLogSection("Running Setup", "RunningSetup")
        $logger.SendFileParameter("BaseImage", $BaseImage)
        $logger.SendParameter("NatSubnetPrefix", $NatSubnetPrefix)
        $logger.SendFileParameter("LogFile", $LogFile)

        $BaseImage = $BaseImage.Replace("`"","")

        $setupScript = Join-Path $myLocation "Setup.ps1"
        & $setupScript -RunInitialSetup -BaseImage $BaseImage -NatSubnetPrefix $NatSubnetPrefix -LogFile ($logger.GetLogFile())

        $Logger.LogDiag("Setup Complete")
        return
    }

    Assert-RequiredFeatureEnabled $logger

    $logger.SendParameter("AppId", $AppId)
    $logger.SendParameter("AppDisplayName", $AppDisplayName)
    $logger.SendParameter("AppDescription", $AppDescription)
    $logger.SendFileParameter("ExpandedBaseImage", $ExpandedBaseImage)
    $logger.SendFileSize("Installer", $Installer)
    $logger.SendFileParameter("Installer", $Installer)
    $logger.SendParameter("InstallerArguments", $InstallerArguments)
    $logger.SendParameter("InstallerValidExitCodes", $InstallerValidExitCodes)
    # There's no value in sending the Destination Command Line parameter, since it's required and is just a filepath.
    $logger.SendParameter("PackageDisplayName", $PackageDisplayName)
    $logger.SendParameter("PackageName", $PackageName)
    $logger.SendParameter("PackagePublisherDisplayName", $PackagePublisherDisplayName)
    $logger.SendParameter("Publisher", $Publisher)
    $logger.SendParameter("Version", $Version)
    $logger.SendParameter("AppInstallPath", $AppInstallPath)
    $logger.SendFileParameter("AppExecutable", $AppExecutable)
    $logger.SendParameter("AppFileTypes", $AppFileTypes)
    $logger.SendSwitchParameter("MakeAppx", $MakeAppx)
    $logger.SendFileParameter("LogFile", $LogFile)

    $hcsDllPath = Join-Path $myLocation "isolation_manager"
    $registryDllPath = (Join-Path $myLocation "registry")
    $commonDllPath = Join-Path $myLocation "common"

    [System.Reflection.Assembly]::LoadFile((Join-Path $commonDllPath "Microsoft.DesktopAppConverter.Common.dll")) > $null
    [System.Reflection.Assembly]::LoadFile((Join-Path $commonDllPath "Microsoft.WindowsAPICodePack.Shell.dll")) > $null
    [System.Reflection.Assembly]::LoadFile((Join-Path $commonDllPath "Microsoft.WindowsAPICodePack.dll")) > $null

    . (Join-Path $myLocation "converter_util\InputValidation.ps1")
    . (Join-Path $myLocation "converter_util\ManifestOps.ps1")
    . (Join-Path $myLocation "converter_util\Sequencer.ps1")
    . (Join-Path $myLocation "manifest\Manifest.ps1")
    . (Join-Path $myLocation "converter_util\RegistryOps.ps1")
    . (Join-Path $myLocation "converter_util\VfsOps.ps1")
    . (Join-Path $myLocation "converter_util\VfsTokenizer.ps1")
    . (Join-Path $myLocation "converter_util\BaseImageOps.ps1")

    if ($MakeAppx)
    {
        $makeAppxFullPath = GetMakeAppxFullPath -Logger $logger
    }

    $pruneRulesFile = (Get-Item (Join-Path $myLocation "converter_util\file_pruner_rules.csv")).FullName

    # Clean Input - PowerShell's missing param prompt will leave quotes on strings causing them to not be recognized as paths
    $Installer = $Installer.Replace("`"","")
    $Destination = $Destination.Replace("`"","")
    $PackageName = $PackageName.Replace("`"","")
    $Publisher = $Publisher.Replace("`"","")

    $logger.NewLogSection("Validating Input", "ValidateInput")

    if ([string]::IsNullOrEmpty($ExpandedBaseImage))
    {
        $ExpandedBaseImage = Get-ExpandedBaseImage -Logger $logger | Select-Object -Last 1
    }

    ValidateExpandedBaseImage -ExpandedBaseImage $ExpandedBaseImage -Logger $logger
    # resolve expanded base image to an absolute path
    $ExpandedBaseImage = (Get-Item -Path $ExpandedBaseImage).FullName

    ValidateInstaller -Installer $Installer -Logger $logger
    ValidateDestination -Destination $Destination -Logger $logger

    if ($AppExecutable)
    {
        $AppExecutable = $AppExecutable -replace "/", "\"
        ValidateAppExecutable -AppExecutable $AppExecutable -Logger $logger
    }

    $installerObj = Get-Item $Installer
    $installerDir = $installerObj.DirectoryName
    $installerName = $installerObj.Name

    $logger.NewLogSection("Setting up Conversion Environment", "SetupEnvironment")

    $hostSharedFolderPath = Join-Path $hostTempLocation "shared"
    $logger.LogDiag("Creating folder to share with isolated environment at $hostSharedFolderPath")
    $hostSharedFolder = (New-Item -Path $hostSharedFolderPath -ItemType Directory -Force).FullName
    $logger.LogDiag("Copying contents of $installerDir to $hostSharedFolder to be shared with isolated environment")
    Copy-Item -Path $installerDir\* -Destination $hostSharedFolder -Recurse

    $packageRoot = (New-Item -Path (Join-Path $hostTempLocation "output") -ItemType Directory -Force).FullName
    $vfsSubFolder = "VFS"
    $vfsRoot = Join-Path $packageRoot $vfsSubFolder

    $installerPath = Join-Path $hostSharedFolder $installerName

    $logger.NewLogSection("Initializing AppxManifest.xml", "InitializeAppxManifest")

    $schemaPath = Join-Path $myLocation "manifest\schema"
    $manifest = [AppxManifest]::new($packageRoot, $schemaPath)
    $application = $manifest.AddPackageApplication()

    # Required Manifest Properties come from mandatory parameters (non-null)
    #  - If the mandatory parameter fails validation against the manifest schema, an exception will be thrown and the script will exit
    $requiredManifestProperties = New-Object 'System.Collections.Generic.List[System.Collections.Hashtable]'

    $requiredManifestProperties.Add(@{"PropertyName" = "PackageName"; "PropertySetMethod" = $manifest.SetPackageIdentityName;      "Value" = $PackageName; })
    $requiredManifestProperties.Add(@{"PropertyName" = "Publisher";   "PropertySetMethod" = $manifest.SetPackageIdentityPublisher; "Value" = $Publisher; })
    $requiredManifestProperties.Add(@{"PropertyName" = "Version";     "PropertySetMethod" = $manifest.SetPackageIdentityVersion;   "Value" = $Version.ToString(); })

    foreach ($property in $requiredManifestProperties)
    {
        Set-ManifestProperty @property -Logger $logger
    }



    # Optional Manifest Properties come from optional parameters (can be null).
    #  - If the optional parameter is not specified, this manifest property gets a default value taken from Required Manifest Properties instead.
    #  - Else if the specified parameter fails validation agains the manifest schema, an exception will be thrown and the script will exit
    $optionalManifestProperties = New-Object 'System.Collections.Generic.List[System.Collections.Hashtable]'

    $optionalManifestProperties.Add(@{"PropertyName" = "PackagePublisherDisplayName"; "PropertySetMethod" = $manifest.SetPackagePropertiesPublisherDisplayName; "Value" = $PackagePublisherDisplayName; "DefaultValue" = $Publisher; })
    $optionalManifestProperties.Add(@{"PropertyName" = "PackageDisplayName";          "PropertySetMethod" = $manifest.SetPackagePropertiesDisplayName;          "Value" = $PackageDisplayName;          "DefaultValue" = $PackageName; })
    $optionalManifestProperties.Add(@{"PropertyName" = "AppDescription";              "PropertySetMethod" = $application.SetVisualElementsDescription;          "Value" = $AppDescription;              "DefaultValue" = $PackageName; })
    $optionalManifestProperties.Add(@{"PropertyName" = "AppDisplayName";              "PropertySetMethod" = $application.SetVisualElementsDisplayName;          "Value" = $AppDisplayName;              "DefaultValue" = $PackageName; })
    $optionalManifestProperties.Add(@{"PropertyName" = "AppId";                       "PropertySetMethod" = $application.SetId;                                 "Value" = $AppId;                       "DefaultValue" = $PackageName; })

    foreach ($property in $optionalManifestProperties)
    {
        Set-ManifestPropertyWithDefault @property -Logger $logger
    }

    $logger.NewLogSection("Running Installer in Isolated Environment", "RunInstaller")

    $sequencerArgs = @{
        ExpandedBaseImage = $ExpandedBaseImage
        Installer = $installerPath
        InstallerArguments = $InstallerArguments
        InstallerValidExitCodes = $InstallerValidExitCodes
        ShareFolder = $hostSharedFolder
        Destination = $packageRoot
        DllPath = $hcsDllPath
        LogPathToken = "<log_folder>"
        Logger = $logger
    }

    Invoke-Sequencer @sequencerArgs
    $logger.LogDiag("Isolated Installer Run Complete!")

    $logger.NewLogSection("Preparing Virtual File System", "PrepareFileSystem")

    $fileArgs = @{
        MetadataProcessorExecutable = (Join-Path $myLocation "metadata_processor\MetadataProcessor.exe")
        Destination = $packageRoot
        Vfs = $vfsRoot
        PruneRulesFile = $pruneRulesFile
        Logger = $logger
    }
    $logger.LogDiag("Begin Convert-Files...")
    Convert-Files @fileArgs

    $logger.NewLogSection("Preparing known folder and application directory layout", "FileTokenization")

    # Create known folder listing 
    $kfp = [Microsoft.Centennial.Tools.DesktopAppConverter.KnownFoldersPrivate]::LoadFromCurrentEnv()
    $knownFoldersListFile = Join-Path $hostTempLocation "KnownFolders.xml"
    $kfp.SaveToXml($knownFoldersListFile)

    # Create a token map
    $tokenMap = New-Object -TypeName Microsoft.Centennial.Tools.DesktopAppConverter.TokenMap
    $tokenMap.AddKnownFolderTokens($knownFoldersListFile)

    # if no AppExecutable was given, try to find it using the shortcut made in the VFS
    if ([string]::IsNullOrEmpty($AppExecutable))
    {
        $logger.LogDiag("AppExecutable param was not specified. Attempting to discover it by searching the VFS for a Start Menu shortcut.")
        $AppExecutableUnverified = Find-Executable -VFS $vfsRoot -Logger $logger

        if (!([string]::IsNullOrEmpty($AppExecutableUnverified)))
        {
            $vfsExecutable = Split-Path $AppExecutableUnverified -NoQualifier

            $logger.LogDiag("A shortcut was found in the VFS that targets $vfsExecutable. Testing that path to ensure the executable is there.")

            $fullVFSExecutable = Join-Path $vfsRoot $vfsExecutable

            if (!(Test-Path $fullVFSExecutable))
            {
                $logger.LogWarning("AppExecutable: warning 4200: Application executable at $vfsExecutable could not be found. Please fix the application executable property in the appxmanifest")
            }
            else
            {
                $logger.LogDiag("The executable path targeted by the discovered shortcut ($vfsExecutable) is a valid path.")
                $AppExecutable = $AppExecutableUnverified
            }
        }
        else
        {
            $logger.LogWarning("AppExecutable: warning 4210: Executable could not be determined from shortcut. Please manually edit the manifest with a path to your executable.")
        }
    }

    if ([string]::IsNullOrEmpty($AppInstallPath) -and !([string]::IsNullOrEmpty($AppExecutable)))
    {
        $logger.LogDiag("AppInstallPath was not specified. Trying to determine the AppInstallPath from AppExecutable path.")
        $AppInstallPath = Get-AppInstallPathFromExePath -ExecutableFile $AppExecutable -KnownFolderListFile $knownFoldersListFile | Select-Object -Last 1
    }

    if (![string]::IsNullOrEmpty($AppInstallPath))
    {
        ValidateAppInstallPath -AppInstallPath $AppInstallPath -VfsRoot $vfsRoot -Logger $Logger
        $logger.LogDiag("Using $AppInstallpath as AppInstallPath")
        $tokenMap.AddTokenByName("AppVPackageRoot", $AppInstallPath)
    }
    else
    {
        $logger.LogWarning("AppInstallPath: warning 4211: Converter couldn't determine your application install path. Please use -AppInstallPath parameter to move app binaries outside of VFS.")
    }
    
    # Create a Vfs Tokenizer
    $VfsTokenizer = [VfsTokenizer]::new($vfsRoot, $tokenMap, $logger)

    # Create tokenized Vfs layout
    $VfsTokenizer.CreateKnownFolderLayout()


    $logger.NewLogSection("Preparing Virtual Registry", "PrepareRegistry")

    $registryArgs = @{
        DllPath = (Join-Path $myLocation "registry")
        SamplePath = (Join-Path $myLocation "registry\NoiseSample\")
        HivesPath = (Join-Path $packageRoot "Hives\")
        Destination = $packageRoot
        TokenMap = $tokenMap
        Logger = $logger
    }
    $logger.LogDiag("Begin Convert-Registry...")
    Convert-Registry @registryArgs


    $logger.NewLogSection("Finalizing AppxManifest.xml", "FinalizeAppxManifest")

    # set app executable value in the manifest
    if (![string]::IsNullOrEmpty($AppExecutable))
    {
        $vfsRelativeAppExecutable = Split-Path -Path $AppExecutable -NoQualifier
        $tokenizedPackageRelative = $VfsTokenizer.GetTokenizedPackageRelativePath($vfsRelativeAppExecutable)

        try
        {
            $application.SetExecutable($tokenizedPackageRelative)
        }
        catch
        {
            $logger.LogWarning("AppExecutable: warning 4230: Appx Manifest validation failed when attempting to set Application Executable to $AppExecutable. Please manually edit the manifest with a path to your executable.")
        }
    }

    # Only try to add FTA/Protocol associations if we have an app executable, that way we can
    # compare that the associated app executable matches the app executable here.
    if (![string]::IsNullOrEmpty($AppExecutable))
    {
        Add-AppFileTypeAssociations $AppFileTypes $packageRoot $application $AppExecutable $logger
        Add-AppProtocolAssociations $AppProtocols $packageRoot $application $AppExecutable $logger
    }

    $logger.LogDiag("Saving manifest...")
    $manifest.Save()

    $logger.NewLogSection("Preparing Final Output", "FinalOutput")

    $logger.LogDiag("Copying placeholder Assets into package...")
    $assetsPath = (Join-Path $myLocation "manifest\assets")
    $packageAssetsPath = (Join-Path $packageRoot "Assets")
    if (!(Test-Path $packageAssetsPath))
    {
        # If the target Assets directory doesn't exist the copy-item call will copy contents of subdirectories one directory lower then it should.
        New-Item $packageAssetsPath -Type Directory > $null
    }
    Copy-Item (Join-Path $assetsPath "*") $packageAssetsPath -Recurse
    $logger.LogDiag("Please replace placeholder assets with your own by changing the files contained at $(Join-Path $Destination "Assets") and/or editing the appx manifest")

    $logger.LogDiag("Copying remaining output into the final output destination...")
    Get-ChildItem -Path $packageRoot -Recurse | Move-Item -Destination $Destination

    if ($MakeAppx)
    {
        $logger.NewLogSection("Making Final Appx Package", "FinalAppx")

        if ($application.IsExecutableChangedFromDefault())
        {
            $destinationFile = (Join-Path $Destination "$PackageName.appx")
            $makeAppxLog = Join-Path $logDirectory "MakeAppx.log"
            & $makeAppxFullPath pack /d $Destination /p $destinationFile | Out-File -FilePath $makeAppxLog -Append -Force
            if (!$?)
            {
                throw "MakeAppx: fatal error 1300: error calling MakeAppx on your package. See $makeAppxLog for details."
            }
            else
            {
                $logger.LogDiag("Appx creation complete. Find it at $destinationFile")
                $logger.SendFileSize("Appx", $destinationFile)
            }
        }
        else
        {
            throw "MakeAppx: fatal error 1310: Unable to create appx package. AppExecutable property in AppxManifest.xml needs to be replaced before calling MakeAppx."
        }
    }

    $logger.LogDiag("Conversion complete. Your converted application is located at $Destination.")

    $logger.SendCompleted();
}
catch
{
    $lastError = $_
    $logger.LogDiag("An error occurred. Refer to logs in $logDirectory")
    $logger.LogDiag($lastError) 4> $null
    $logger.LogDiag($lastError.ScriptStackTrace) 4> $null
    $logger.SendFatalException($lastError)
    throw $lastError
}

# SIG # Begin signature block
# MIIkJwYJKoZIhvcNAQcCoIIkGDCCJBQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBEJrmkzlg17hnU
# kO0NtHDByZmQXxXxHb/gq+lr5NiCHqCCDZIwggYQMIID+KADAgECAhMzAAAAZEeE
# lIbbQRk4AAAAAABkMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTUxMDI4MjAzMTQ2WhcNMTcwMTI4MjAzMTQ2WjCBgzEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9Q
# UjEeMBwGA1UEAxMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAky7a2OY+mNkbD2RfTahYTRQ793qE/DwRMTrvicJK
# LUGlSF3dEp7vq2YoNNV9KlV7TE2K8sDxstNSFYu2swi4i1AL3X/7agmg3GcExPHf
# vHUYIEC+eCyZVt3u9S7dPkL5Wh8wrgEUirCCtVGg4m1l/vcYCo0wbU06p8XzNi3u
# XyygkgCxHEziy/f/JCV/14/A3ZduzrIXtsccRKckyn6B5uYxuRbZXT7RaO6+zUjQ
# hiyu3A4hwcCKw+4bk1kT9sY7gHIYiFP7q78wPqB3vVKIv3rY6LCTraEbjNR+phBQ
# EL7hyBxk+ocu+8RHZhbAhHs2r1+6hURsAg8t4LAOG6I+JQIDAQABo4IBfzCCAXsw
# HwYDVR0lBBgwFgYIKwYBBQUHAwMGCisGAQQBgjdMCAEwHQYDVR0OBBYEFFhWcQTw
# vbsz9YNozOeARvdXr9IiMFEGA1UdEQRKMEikRjBEMQ0wCwYDVQQLEwRNT1BSMTMw
# MQYDVQQFEyozMTY0Mis0OWU4YzNmMy0yMzU5LTQ3ZjYtYTNiZS02YzhjNDc1MWM0
# YjYwHwYDVR0jBBgwFoAUSG5k5VAF04KqFzc3IrVtqMp1ApUwVAYDVR0fBE0wSzBJ
# oEegRYZDaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljQ29k
# U2lnUENBMjAxMV8yMDExLTA3LTA4LmNybDBhBggrBgEFBQcBAQRVMFMwUQYIKwYB
# BQUHMAKGRWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWlj
# Q29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNydDAMBgNVHRMBAf8EAjAAMA0GCSqG
# SIb3DQEBCwUAA4ICAQCI4gxkQx3dXK6MO4UktZ1A1r1mrFtXNdn06DrARZkQTdu0
# kOTLdlGBCfCzk0309RLkvUgnFKpvLddrg9TGp3n80yUbRsp2AogyrlBU+gP5ggHF
# i7NjGEpj5bH+FDsMw9PygLg8JelgsvBVudw1SgUt625nY7w1vrwk+cDd58TvAyJQ
# FAW1zJ+0ySgB9lu2vwg0NKetOyL7dxe3KoRLaztUcqXoYW5CkI+Mv3m8HOeqlhyf
# FTYxPB5YXyQJPKQJYh8zC9b90JXLT7raM7mQ94ygDuFmlaiZ+QSUR3XVupdEngrm
# ZgUB5jX13M+Pl2Vv7PPFU3xlo3Uhj1wtupNC81epoxGhJ0tRuLdEajD/dCZ0xIni
# esRXCKSC4HCL3BMnSwVXtIoj/QFymFYwD5+sAZuvRSgkKyD1rDA7MPcEI2i/Bh5O
# MAo9App4sR0Gp049oSkXNhvRi/au7QG6NJBTSBbNBGJG8Qp+5QThKoQUk8mj0ugr
# 4yWRsA9JTbmqVw7u9suB5OKYBMUN4hL/yI+aFVsE/KJInvnxSzXJ1YHka45ADYMK
# AMl+fLdIqm3nx6rIN0RkoDAbvTAAXGehUCsIod049A1T3IJyUJXt3OsTd3WabhIB
# XICYfxMg10naaWcyUePgW3+VwP0XLKu4O1+8ZeGyaDSi33GnzmmyYacX3BTqMDCC
# B3owggVioAMCAQICCmEOkNIAAAAAAAMwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29m
# dCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDExMB4XDTExMDcwODIwNTkw
# OVoXDTI2MDcwODIxMDkwOVowfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAx
# MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAKvw+nIQHC6t2G6qghBN
# NLrytlghn0IbKmvpWlCquAY4GgRJun/DDB7dN2vGEtgL8DjCmQawyDnVARQxQtOJ
# DXlkh36UYCRsr55JnOloXtLfm1OyCizDr9mpK656Ca/XllnKYBoF6WZ26DJSJhIv
# 56sIUM+zRLdd2MQuA3WraPPLbfM6XKEW9Ea64DhkrG5kNXimoGMPLdNAk/jj3gcN
# 1Vx5pUkp5w2+oBN3vpQ97/vjK1oQH01WKKJ6cuASOrdJXtjt7UORg9l7snuGG9k+
# sYxd6IlPhBryoS9Z5JA7La4zWMW3Pv4y07MDPbGyr5I4ftKdgCz1TlaRITUlwzlu
# ZH9TupwPrRkjhMv0ugOGjfdf8NBSv4yUh7zAIXQlXxgotswnKDglmDlKNs98sZKu
# HCOnqWbsYR9q4ShJnV+I4iVd0yFLPlLEtVc/JAPw0XpbL9Uj43BdD1FGd7P4AOG8
# rAKCX9vAFbO9G9RVS+c5oQ/pI0m8GLhEfEXkwcNyeuBy5yTfv0aZxe/CHFfbg43s
# TUkwp6uO3+xbn6/83bBm4sGXgXvt1u1L50kppxMopqd9Z4DmimJ4X7IvhNdXnFy/
# dygo8e1twyiPLI9AN0/B4YVEicQJTMXUpUMvdJX3bvh4IFgsE11glZo+TzOE2rCI
# F96eTvSWsLxGoGyY0uDWiIwLAgMBAAGjggHtMIIB6TAQBgkrBgEEAYI3FQEEAwIB
# ADAdBgNVHQ4EFgQUSG5k5VAF04KqFzc3IrVtqMp1ApUwGQYJKwYBBAGCNxQCBAwe
# CgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0j
# BBgwFoAUci06AjGQQ7kUBU7h6qfHMdEjiTQwWgYDVR0fBFMwUTBPoE2gS4ZJaHR0
# cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2Vy
# QXV0MjAxMV8yMDExXzAzXzIyLmNybDBeBggrBgEFBQcBAQRSMFAwTgYIKwYBBQUH
# MAKGQmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2Vy
# QXV0MjAxMV8yMDExXzAzXzIyLmNydDCBnwYDVR0gBIGXMIGUMIGRBgkrBgEEAYI3
# LgMwgYMwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lv
# cHMvZG9jcy9wcmltYXJ5Y3BzLmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBh
# AGwAXwBwAG8AbABpAGMAeQBfAHMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG
# 9w0BAQsFAAOCAgEAZ/KGpZjgVHkaLtPYdGcimwuWEeFjkplCln3SeQyQwWVfLiw+
# +MNy0W2D/r4/6ArKO79HqaPzadtjvyI1pZddZYSQfYtGUFXYDJJ80hpLHPM8QotS
# 0LD9a+M+By4pm+Y9G6XUtR13lDni6WTJRD14eiPzE32mkHSDjfTLJgJGKsKKELuk
# qQUMm+1o+mgulaAqPyprWEljHwlpblqYluSD9MCP80Yr3vw70L01724lruWvJ+3Q
# 3fMOr5kol5hNDj0L8giJ1h/DMhji8MUtzluetEk5CsYKwsatruWy2dsViFFFWDgy
# cScaf7H0J/jeLDogaZiyWYlobm+nt3TDQAUGpgEqKD6CPxNNZgvAs0314Y9/HG8V
# fUWnduVAKmWjw11SYobDHWM2l4bf2vP48hahmifhzaWX0O5dY0HjWwechz4GdwbR
# BrF1HxS+YWG18NzGGwS+30HHDiju3mUv7Jf2oVyW2ADWoUa9WfOXpQlLSBCZgB/Q
# ACnFsZulP0V3HjXG0qKin3p6IvpIlR+r+0cjgPWe+L9rt0uX4ut1eBrs6jeZeRhL
# /9azI2h15q/6/IvrC4DqaTuv/DDtBEyO3991bWORPdGdVk5Pv4BXIqF4ETIheu9B
# CrE/+6jMpF3BoYibV3FWTkhFwELJm3ZbCoBIa/15n8G9bW1qyVJzEw16UM0xghXr
# MIIV5wIBATCBlTB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExAhMzAAAA
# ZEeElIbbQRk4AAAAAABkMA0GCWCGSAFlAwQCAQUAoIHWMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDFJIQH773EZstguJ6w4TD0U252MzprtiWNhveduY4SpDBqBgor
# BgEEAYI3AgEMMVwwWqAugCwAVwBpAG4AZABvAHcAcwAgAFAAaABvAG4AZQAgAFAA
# YQBjAGsAYQBnAGUAc6EogCZodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vd2luZG93
# c3Bob25lLzANBgkqhkiG9w0BAQEFAASCAQBLiFaOG5dnZWINLKnKBjr10266Opuf
# NN/Azm92bgDulGHV1r7j7hJVmXwuizme7Vz6+/h/U+l8TtYjfEHtT3c+41Gp9vyt
# wxQ9PpW7VMzvpvtt166mBW9fEN03MXUMuEwztmz0AD85N/6UbIkcuC8dpbcmbEF0
# OxnNJzNvfTbDKOEJHDrck9BGINXuRXVFHkPmADwIg+B7U6Nyju2Jj1Wq54xwrzPI
# BLM0IiR8mJBT5qUXq6lzHR0mSBFVWt7I0hWu5yu9oO1qPD5q2q3JC0qGMAcpDq22
# onZ/FCBmnVhvlNWfISHDwQeVT++ea/iRV8renWJm2qk68LO1RwlLVI5VoYITTTCC
# E0kGCisGAQQBgjcDAwExghM5MIITNQYJKoZIhvcNAQcCoIITJjCCEyICAQMxDzAN
# BglghkgBZQMEAgEFADCCAT0GCyqGSIb3DQEJEAEEoIIBLASCASgwggEkAgEBBgor
# BgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIAlK3qfC9Ueq76sLm/2uKDGkAHfp
# ddUxJFBFvXGqqojiAgZXIOciWw4YEzIwMTYwNTExMDIyMDI4LjE1M1owBwIBAYAC
# AfSggbmkgbYwgbMxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# DTALBgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjo3RDJFLTM3
# ODItQjBGNzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# DtAwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNy
# b3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEy
# MTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwT
# l/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4J
# E458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhg
# RvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchoh
# iq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajy
# eioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwB
# BU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVj
# OlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsG
# A1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJc
# YmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9z
# b2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIz
# LmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0
# MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYx
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0
# bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMA
# dABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCY
# P4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1r
# VFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3
# fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2
# /QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFj
# nXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjgg
# tSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7
# cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwms
# ObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAv
# VCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGv
# WbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA1
# 2u8JJxzVs341Hgi62jbb01+P3nSISRIwggTaMIIDwqADAgECAhMzAAAAdrYQ4XyH
# IzwiAAAAAAB2MA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwMB4XDTE1MTAwNzE4MTc0MFoXDTE3MDEwNzE4MTc0MFowgbMxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIxJzAl
# BgNVBAsTHm5DaXBoZXIgRFNFIEVTTjo3RDJFLTM3ODItQjBGNzElMCMGA1UEAxMc
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQAD
# ggEPADCCAQoCggEBAKMFk/N0yGDhLMtQW3kOqJ4Z0I/SJKMGYbpWlrU6lAGi4Gfd
# 6REj/v6CYhk/DbyHJ5LmZlFQrve1EfsGDqij9yZbg+/CbljqTchT65F4EHXGBr6D
# kMBpuuhZd3roWnayqmIDcc9TeNeWJ9iXfreEgL/MOuhW3jQNsUX8CIA7kvwKNcr8
# U/UIcR8qZvRgVo4dMhxkH1yhaSU5lR0qVndwh75w4MbFbRg5pkP5TuoSLQauZ24x
# 6oysX7IPxnsWCdNj8GHrDlVj9U2qAMgZ07S6UQItrZKBbmyFZkaS86MtU1RKCUHS
# 48sojm2+WGQp63codmL/YXzO9MPTwb3lncFjIYMCAwEAAaOCARswggEXMB0GA1Ud
# DgQWBBT0FIVIPPf676xoDtCRqcertABcyzAfBgNVHSMEGDAWgBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5j
# cmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAM
# BgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUA
# A4IBAQBatESgWH1l3/tDq3qZmgvO3XSwYE5Pm6ueYySASN9K26lyAhyD2h0ZnSiW
# CkvrcaqqL0CV5lKHih4Pj3MpNZNjxYx0OHLatEfBiHj92uIs1kmbkfKbe1lsdmSH
# ufhbX23D1+Tlh5LWJKLhiwehYhVOvb6/+wVx3kAX+hkJPVd12xMnZXczCME/sNT9
# ibrlnJFSs6G4vNx/PTa7bXFJhKqFPNsGgGK/mPxPtwXdTgVJO/orfSzVmkHgC3iX
# lXFKdCjxOQvIRqwAOELfyS15I38n6FelzU3Y7obGqOtXtcyAgOh0fecCJ1PRnCFz
# RMUCRxBroucAUxSk/he5M9n/eGzIoYIDeTCCAmECAQEwgeOhgbmkgbYwgbMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# JzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjo3RDJFLTM3ODItQjBGNzElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIlCgEBMAkGBSsOAwIaBQAD
# FQDeHTu9FPbcUDPm0TdIfTmT4JN3L6CBwjCBv6SBvDCBuTELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMe
# bkNpcGhlciBOVFMgRVNOOjU3RjYtQzFFMC01NTRDMSswKQYDVQQDEyJNaWNyb3Nv
# ZnQgVGltZSBTb3VyY2UgTWFzdGVyIENsb2NrMA0GCSqGSIb3DQEBBQUAAgUA2tz7
# HTAiGA8yMDE2MDUxMTAwMjgxM1oYDzIwMTYwNTEyMDAyODEzWjB3MD0GCisGAQQB
# hFkKBAExLzAtMAoCBQDa3PsdAgEAMAoCAQACAgfrAgH/MAcCAQACAhhyMAoCBQDa
# 3kydAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwGgCjAIAgEAAgMW
# 42ChCjAIAgEAAgMHoSAwDQYJKoZIhvcNAQEFBQADggEBABcqkD8hGZqjhDt6z8J9
# ZVfCTtNWkhttgehZJjDx82RJQH4+ybI8iSOGuRcz0nJBWYR4+Jl4nzlyHNvlUigG
# jesCn8Mg8M2QaqrVZglXdU6gTfp2ZEH7AlRjC4vwu4eE7s7auYuMOlOF7zSza8Vl
# wJURdC29yS12S1cgN9KN7csaTuiMbUCcepMQbxoJwc4/34g5G6hacvh1mT+cX4GS
# 06FvsLFCroWnurE1TQd9nrth6p9cLlqjJAfMKLLQuMn8Njg5uh7jf/+hDj6TXDnl
# yPtXfsXZAXUSHd0iQ+YOUdQILGkEU49XY3eu0hPCpUwaWSWX9tWY/TjxpgoVuM0q
# NhAxggL1MIIC8QIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAIT
# MwAAAHa2EOF8hyM8IgAAAAAAdjANBglghkgBZQMEAgEFAKCCATIwGgYJKoZIhvcN
# AQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCBNwNj3Kqdu3En0aSrL
# rDN28gvzNT87o5k0uSkauezLSDCB4gYLKoZIhvcNAQkQAgwxgdIwgc8wgcwwgbEE
# FN4dO70U9txQM+bRN0h9OZPgk3cvMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTACEzMAAAB2thDhfIcjPCIAAAAAAHYwFgQUC44L21EVWpTOgaRJ
# eZG94RElQeIwDQYJKoZIhvcNAQELBQAEggEAdOvCYGFpJOHjCRKGEzKxoC1xvitv
# ZltuF+4yigcmuYhXgav6lX59MKqSRjYck7NymFaoFkzQl5ToOVXIXMVy/2iom+et
# 9OCHdkQFnp/BMqgfP5Ot2dBSSpczfJI/ClB85BJCD2DXispkqg2y9Cv1G0JDXQcp
# vpDwtwAWoceA9B5wIrwe9fXgGoHyE9+da29/SLnoAY+lZWcabwKQ5oG9jWKe6WaF
# qnF+HMOglnXSVTdk7F6BVh/vgcABiAdmSGd2tPxy33/IIZ6HNZEkn2qGkUk8jq03
# N+hFBxHvNDuXKvPz0otRPlKMUP5nvxu0tLJ2lD8+vnyjfX9YZDc/WdrUMg==
# SIG # End signature block
