﻿<#
    .SYNOPSIS
        Provides cmdlets for various logging information and sending telemetry.
    .DESCRIPTION
        This acts as a Logger and Telemetry library.
        "Log" functions are meant to help users diagnose errors.
        "Send" functions are meant to help us improve the product and fix issues users hit.
        They are separate functions, since we need to be judicious in what we send back through telemetry.
#>

Class CWACLogger
{

    [string] $_logFile
    [DateTime] $_scriptStartTime
    [DateTime] $_sectionStartTime
    [string] $_sectionTitleShort
    [hashtable] $_extensions
    [hashtable] $_folders
    $_telemetry

    CWACLogger()
    {
    }

    CWACLogger([string] $logFile, [string] $DllPath)
    {
        if ([string]::IsNullOrEmpty($logFile))
        {
            throw "Log File parameter cannot be null or empty"
        }
        $this._logFile = $logFile

        [System.Reflection.Assembly]::LoadFile((Join-Path $DllPath "Microsoft.DesktopAppConverter.Telemetry.dll")) > $null
        [System.Reflection.Assembly]::LoadFile((Join-Path $DllPath "Microsoft.ApplicationInsights.dll")) > $null
        $this._telemetry = New-Object -TypeName Microsoft.Centennial.Tools.DesktopAppConverter.Telemetry

        $this._scriptStartTime = Get-Date
        $this._extensions = @{}
        $this._folders = @{}
    }

    [string] GetLogFile()
    {
        return $this._logFile
    }

    [void] LogError([string] $msg)
    {
        Write-Error $msg
        $this.LogToFile($msg)
        $this._telemetry.SendError($msg)
    }

    [void] LogDiag([string] $msg)
    {
        Write-Verbose $msg
        $this.LogToFile($msg)
    }

    [void] LogWarning([string] $msg)
    {
        Write-Warning $msg
        $this.LogToFile($msg)
        $this._telemetry.SendWarning($msg)
    }

    [void] LogToFile([string] $msg)
    {
        if ($this._logFile)
        {
            $this.FormatLogMessage($msg) | Out-File -FilePath $this._logFile -Append
        }
    }

    [string] FormatLogMessage([String] $msg)
    {
        return "[$(Get-Date -format s)] $msg"
    }

    # Start a new log section and also log the time taken.  We also need a shortened version
    # since it makes the telemetry easier to read.
    [void] NewLogSection([string] $sectionTitle, [string] $sectionTitleShort)
    {
        $newline = "`r`n"
        $formattedTitle = '-' * 50 + $newline * 3 + $sectionTitle + $newline * 2
        $this.LogDiag($formattedTitle)

        $this.SendSectionTime($sectionTitleShort)
    }

    # Log the version of our tools.
    [void] LogVersion([string] $version)
    {
        $this.LogDiag($version)
        $this._telemetry.SetVersion($version)
    }

    # Send how long the previous section took, and start timing the new section
    [void] SendSectionTime([String] $sectionTitleShort)
    {
        # The very first time this is called, don't send anything.  It's the very first section
        # so the "previous" section doesn't exist.
        if ($this._sectionTitleShort)
        {
            $this.SendTimeTaken($this._sectionTitleShort, $(Get-Date) - $this._sectionStartTime)
        }

        $this._sectionStartTime = Get-Date
        $this._sectionTitleShort = $sectionTitleShort
    }

    # Send how long an event took.
    [void] SendTimeTaken([String] $event, [TimeSpan] $duration)
    {
        # Telemetry class uses doubles for all metrics (no concept of a TimeSpan), so tack on
        # "Seconds" to help document what type it is.
        $this._telemetry.SendMetric("$($event)Seconds", [math]::Round($duration.TotalSeconds))
    }

    # Send how large a file is.
    [void] SendFileSize([String] $name, [String] $fileNameAndPath)
    { 
        if (Test-Path $fileNameAndPath)
        {
            $file = Get-Item($fileNameAndPath)
            if ($file)
            {
                # Round to nearest KB, since Windows Explorer shows KB by default and it's what most people expect.
                $sizeKB = [math]::Round($file.Length/1KB)

                $this._telemetry.SendMetric("$($name)FileSizeKB", $sizeKB)
            }
        }
    }

    # Parse and send command line file parameter stripped of the path.
    [void] SendFileParameter([String] $name, [String] $file)
    {
        if (!([string]::IsNullOrEmpty($file)) -and (Test-Path $file))
        {
            # Remove filepath, since that could contain PII.
            $filename = Split-Path $file -Leaf
            $this._telemetry.SendProperty("$($name)Parameter", $filename)
        }
    }

    # Send a command line parameter if it exists.
    [void] SendParameter([String] $name, [String] $parameter)
    {
        if (!([string]::IsNullOrEmpty($parameter)))
        {
            $this._telemetry.SendProperty("$($name)Parameter", $parameter)
        }
    }

    # Send a switch command line parameter.
    [void] SendSwitchParameter([String] $name, [switch] $parameter)
    {
        $this._telemetry.SendProperty("$($name)Parameter", $parameter)
    }

    # Send a name and value pair.
    [void] SendValue([String] $name, [double] $value)
    {
        $this._telemetry.SendMetric($name, $value)
    }

    # Send file information.  We just care about file extensions and basic folder paths.
    # Batch the data up, and send at the end.
    [void] SendFileData([String] $rootName, [String] $fileName)
    {
        # We only need a set collection class and not a hashtable, but hashtables are better
        # supported in PowerShell.  So for the value, just use 1, which essentially gives us a set.
        $extension = [System.IO.Path]::GetExtension($fileName).ToLower()
        $this._extensions[$extension] = 1

        # Send the directory the file is located in, but only up to two levels deep.
        # We only care about in general where the file is going (ex. \Windows\System32), and this
        # helps prevent sending hundreds of folders.  For example, this should convert:
        #   "\<DesktopAppConverterDirectory>\Program Files(x86)\notepad\manuals\manual.txt" to
        #   "\Program Files(x86)\notepad"
        $folder = [System.IO.Path]::GetDirectoryName($filename).ToLower()
        $subFolder = $folder.Substring($rootName.Length)

        try
        {
            $slash = $subFolder.IndexOf('\', 1)
            if ($slash -ge 0)
            {
                $slash = $subFolder.IndexOf('\', $slash+1)
                if ($slash -ge 0)
                {
                    $subFolder = $subFolder.Substring(0, $slash)
                }
            }
        }
        catch
        {
            # This means there is less than two subfolders (ex. "\Fabrikam"), so just
            # return the entire folder path
        }

        $this._folders[$subFolder] = 1
    }

    # Send the data we have batched up.
    # * How long it took for the entire script to run
    # * Was there an error?
    # * All placed file data
    [void] SendAllBatchedData()
    {
        $this.SendTimeTaken("Overall", $(Get-Date) - $this._scriptStartTime)

        # Send out the final section time, and don't worry about starting another section
        # so just pass "".
        $this.SendSectionTime("");

        # Send out folders, comma delimited.  For example: "\Program Files(x86)\notepad, \Windows\System32"
        $folders = ($this._folders.Keys -join ", ")
        $this._telemetry.SendProperty("PlacedFolders", $folders)

        # Send out extensions, comma delimited.  For example: ".txt, .doc, .rtf"
        # Call it "PlacedExtensions" instead of "Extensions", since it helps differentiate it from
        # the file extensions they can register for.
        $extensions = ($this._extensions.Keys -join ", ")
        $this._telemetry.SendProperty("PlacedExtensions", $extensions)
    }

    # Send the fatal exception.
    [void] SendFatalException($errorRecord)
    {
        $this.SendAllBatchedData()
        $this._telemetry.SendFatalException($errorRecord.Exception)
    }

    # Send the final telemetry
    [void] SendCompleted()
    {
        $this.SendAllBatchedData()
        $this._telemetry.SendCompleted()
    }

    # Send the final telemetry for -Setup runs
    [void] SendSetupCompleted()
    {
        $this.SendAllBatchedData()
        $this._telemetry.SendSetupCompleted()
    }

    # Send intermediate telemetry for -Setup runs before the system reboots
    [void] SendEnableFeatureCompleted()
    {
        $this.SendAllBatchedData()
        $this._telemetry.SendEnableFeatureCompleted()
    }
}
# SIG # Begin signature block
# MIIkJwYJKoZIhvcNAQcCoIIkGDCCJBQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD7lyIbYwlOdpId
# 8Aq96ldeokr1QxcNBER+79YVsjDL+qCCDZIwggYQMIID+KADAgECAhMzAAAAZEeE
# lIbbQRk4AAAAAABkMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTUxMDI4MjAzMTQ2WhcNMTcwMTI4MjAzMTQ2WjCBgzEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9Q
# UjEeMBwGA1UEAxMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAky7a2OY+mNkbD2RfTahYTRQ793qE/DwRMTrvicJK
# LUGlSF3dEp7vq2YoNNV9KlV7TE2K8sDxstNSFYu2swi4i1AL3X/7agmg3GcExPHf
# vHUYIEC+eCyZVt3u9S7dPkL5Wh8wrgEUirCCtVGg4m1l/vcYCo0wbU06p8XzNi3u
# XyygkgCxHEziy/f/JCV/14/A3ZduzrIXtsccRKckyn6B5uYxuRbZXT7RaO6+zUjQ
# hiyu3A4hwcCKw+4bk1kT9sY7gHIYiFP7q78wPqB3vVKIv3rY6LCTraEbjNR+phBQ
# EL7hyBxk+ocu+8RHZhbAhHs2r1+6hURsAg8t4LAOG6I+JQIDAQABo4IBfzCCAXsw
# HwYDVR0lBBgwFgYIKwYBBQUHAwMGCisGAQQBgjdMCAEwHQYDVR0OBBYEFFhWcQTw
# vbsz9YNozOeARvdXr9IiMFEGA1UdEQRKMEikRjBEMQ0wCwYDVQQLEwRNT1BSMTMw
# MQYDVQQFEyozMTY0Mis0OWU4YzNmMy0yMzU5LTQ3ZjYtYTNiZS02YzhjNDc1MWM0
# YjYwHwYDVR0jBBgwFoAUSG5k5VAF04KqFzc3IrVtqMp1ApUwVAYDVR0fBE0wSzBJ
# oEegRYZDaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljQ29k
# U2lnUENBMjAxMV8yMDExLTA3LTA4LmNybDBhBggrBgEFBQcBAQRVMFMwUQYIKwYB
# BQUHMAKGRWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWlj
# Q29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNydDAMBgNVHRMBAf8EAjAAMA0GCSqG
# SIb3DQEBCwUAA4ICAQCI4gxkQx3dXK6MO4UktZ1A1r1mrFtXNdn06DrARZkQTdu0
# kOTLdlGBCfCzk0309RLkvUgnFKpvLddrg9TGp3n80yUbRsp2AogyrlBU+gP5ggHF
# i7NjGEpj5bH+FDsMw9PygLg8JelgsvBVudw1SgUt625nY7w1vrwk+cDd58TvAyJQ
# FAW1zJ+0ySgB9lu2vwg0NKetOyL7dxe3KoRLaztUcqXoYW5CkI+Mv3m8HOeqlhyf
# FTYxPB5YXyQJPKQJYh8zC9b90JXLT7raM7mQ94ygDuFmlaiZ+QSUR3XVupdEngrm
# ZgUB5jX13M+Pl2Vv7PPFU3xlo3Uhj1wtupNC81epoxGhJ0tRuLdEajD/dCZ0xIni
# esRXCKSC4HCL3BMnSwVXtIoj/QFymFYwD5+sAZuvRSgkKyD1rDA7MPcEI2i/Bh5O
# MAo9App4sR0Gp049oSkXNhvRi/au7QG6NJBTSBbNBGJG8Qp+5QThKoQUk8mj0ugr
# 4yWRsA9JTbmqVw7u9suB5OKYBMUN4hL/yI+aFVsE/KJInvnxSzXJ1YHka45ADYMK
# AMl+fLdIqm3nx6rIN0RkoDAbvTAAXGehUCsIod049A1T3IJyUJXt3OsTd3WabhIB
# XICYfxMg10naaWcyUePgW3+VwP0XLKu4O1+8ZeGyaDSi33GnzmmyYacX3BTqMDCC
# B3owggVioAMCAQICCmEOkNIAAAAAAAMwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29m
# dCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDExMB4XDTExMDcwODIwNTkw
# OVoXDTI2MDcwODIxMDkwOVowfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAx
# MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAKvw+nIQHC6t2G6qghBN
# NLrytlghn0IbKmvpWlCquAY4GgRJun/DDB7dN2vGEtgL8DjCmQawyDnVARQxQtOJ
# DXlkh36UYCRsr55JnOloXtLfm1OyCizDr9mpK656Ca/XllnKYBoF6WZ26DJSJhIv
# 56sIUM+zRLdd2MQuA3WraPPLbfM6XKEW9Ea64DhkrG5kNXimoGMPLdNAk/jj3gcN
# 1Vx5pUkp5w2+oBN3vpQ97/vjK1oQH01WKKJ6cuASOrdJXtjt7UORg9l7snuGG9k+
# sYxd6IlPhBryoS9Z5JA7La4zWMW3Pv4y07MDPbGyr5I4ftKdgCz1TlaRITUlwzlu
# ZH9TupwPrRkjhMv0ugOGjfdf8NBSv4yUh7zAIXQlXxgotswnKDglmDlKNs98sZKu
# HCOnqWbsYR9q4ShJnV+I4iVd0yFLPlLEtVc/JAPw0XpbL9Uj43BdD1FGd7P4AOG8
# rAKCX9vAFbO9G9RVS+c5oQ/pI0m8GLhEfEXkwcNyeuBy5yTfv0aZxe/CHFfbg43s
# TUkwp6uO3+xbn6/83bBm4sGXgXvt1u1L50kppxMopqd9Z4DmimJ4X7IvhNdXnFy/
# dygo8e1twyiPLI9AN0/B4YVEicQJTMXUpUMvdJX3bvh4IFgsE11glZo+TzOE2rCI
# F96eTvSWsLxGoGyY0uDWiIwLAgMBAAGjggHtMIIB6TAQBgkrBgEEAYI3FQEEAwIB
# ADAdBgNVHQ4EFgQUSG5k5VAF04KqFzc3IrVtqMp1ApUwGQYJKwYBBAGCNxQCBAwe
# CgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0j
# BBgwFoAUci06AjGQQ7kUBU7h6qfHMdEjiTQwWgYDVR0fBFMwUTBPoE2gS4ZJaHR0
# cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2Vy
# QXV0MjAxMV8yMDExXzAzXzIyLmNybDBeBggrBgEFBQcBAQRSMFAwTgYIKwYBBQUH
# MAKGQmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2Vy
# QXV0MjAxMV8yMDExXzAzXzIyLmNydDCBnwYDVR0gBIGXMIGUMIGRBgkrBgEEAYI3
# LgMwgYMwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lv
# cHMvZG9jcy9wcmltYXJ5Y3BzLmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBh
# AGwAXwBwAG8AbABpAGMAeQBfAHMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG
# 9w0BAQsFAAOCAgEAZ/KGpZjgVHkaLtPYdGcimwuWEeFjkplCln3SeQyQwWVfLiw+
# +MNy0W2D/r4/6ArKO79HqaPzadtjvyI1pZddZYSQfYtGUFXYDJJ80hpLHPM8QotS
# 0LD9a+M+By4pm+Y9G6XUtR13lDni6WTJRD14eiPzE32mkHSDjfTLJgJGKsKKELuk
# qQUMm+1o+mgulaAqPyprWEljHwlpblqYluSD9MCP80Yr3vw70L01724lruWvJ+3Q
# 3fMOr5kol5hNDj0L8giJ1h/DMhji8MUtzluetEk5CsYKwsatruWy2dsViFFFWDgy
# cScaf7H0J/jeLDogaZiyWYlobm+nt3TDQAUGpgEqKD6CPxNNZgvAs0314Y9/HG8V
# fUWnduVAKmWjw11SYobDHWM2l4bf2vP48hahmifhzaWX0O5dY0HjWwechz4GdwbR
# BrF1HxS+YWG18NzGGwS+30HHDiju3mUv7Jf2oVyW2ADWoUa9WfOXpQlLSBCZgB/Q
# ACnFsZulP0V3HjXG0qKin3p6IvpIlR+r+0cjgPWe+L9rt0uX4ut1eBrs6jeZeRhL
# /9azI2h15q/6/IvrC4DqaTuv/DDtBEyO3991bWORPdGdVk5Pv4BXIqF4ETIheu9B
# CrE/+6jMpF3BoYibV3FWTkhFwELJm3ZbCoBIa/15n8G9bW1qyVJzEw16UM0xghXr
# MIIV5wIBATCBlTB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExAhMzAAAA
# ZEeElIbbQRk4AAAAAABkMA0GCWCGSAFlAwQCAQUAoIHWMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCA9cOdcbxHcr+Hg4HAxnXoNnwQLOIzvPwZTgF1AbI+XcTBqBgor
# BgEEAYI3AgEMMVwwWqAugCwAVwBpAG4AZABvAHcAcwAgAFAAaABvAG4AZQAgAFAA
# YQBjAGsAYQBnAGUAc6EogCZodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vd2luZG93
# c3Bob25lLzANBgkqhkiG9w0BAQEFAASCAQBjmWWRHdSUum7/GZqrCVc03MofbdWY
# KKcAaAvu6nQDLa3rEGp6Orw9rsJiTOnNBBcg3nZxKd3dzzNQfGlLKZ7JUM30tPcl
# v5n1zPv1NMod2RFcjRKhjhwA/i6wVfr+zjA9RGixNahGcnT1I7DymDBMZAUwibAi
# hJdnG+h3plGPvVVWl4RwM4PJKHUa9n7sUa5YcBTtHws9ZjEph03PkFFEqOoIQre1
# fn+By8OcqYjhkqdSL4i89/WcV9ulNIrzTDv5kwecUTOPcRxOKKresdMmx+fxn71A
# yj4mG2SuF+9aj0iYFbXw45/00UbIcCGXnjDAz9CVqaYBBgtqZsrqNJrZoYITTTCC
# E0kGCisGAQQBgjcDAwExghM5MIITNQYJKoZIhvcNAQcCoIITJjCCEyICAQMxDzAN
# BglghkgBZQMEAgEFADCCAT0GCyqGSIb3DQEJEAEEoIIBLASCASgwggEkAgEBBgor
# BgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIEyUqPTTTRG7drpdmpgBFYY5/f5v
# xT2XcmnVnOlRu/EqAgZXIVeZ4/QYEzIwMTYwNTExMDIyMDI4LjI5OVowBwIBAYAC
# AfSggbmkgbYwgbMxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# DTALBgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjpCMUI3LUY2
# N0YtRkVDMjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# DtAwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNy
# b3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEy
# MTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwT
# l/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4J
# E458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhg
# RvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchoh
# iq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajy
# eioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwB
# BU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVj
# OlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsG
# A1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJc
# YmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9z
# b2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIz
# LmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0
# MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYx
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0
# bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMA
# dABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCY
# P4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1r
# VFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3
# fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2
# /QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFj
# nXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjgg
# tSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7
# cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwms
# ObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAv
# VCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGv
# WbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA1
# 2u8JJxzVs341Hgi62jbb01+P3nSISRIwggTaMIIDwqADAgECAhMzAAAAhlz7jOh0
# Pf2vAAAAAACGMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwMB4XDTE2MDMzMDE5MjQyNFoXDTE3MDYzMDE5MjQyNFowgbMxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIxJzAl
# BgNVBAsTHm5DaXBoZXIgRFNFIEVTTjpCMUI3LUY2N0YtRkVDMjElMCMGA1UEAxMc
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQAD
# ggEPADCCAQoCggEBANee3MXq4+gdtJMeUYTNpPTRG7n3C5SHk5o2CwsmvaGUFK9f
# 4q40HShfvUBWcyWSEed76RYcOWK+BRMWLdBte+/OLBsiRuT3fPCsn+5tCrXFoOu6
# SMZB41UXkYJCwg7HBvBXNbkb0SM9F19t4wTRgMfWs2QZxpZY7Q4/LRhUZAKmPZe0
# c0Pqn016Bxk6GirV/Dcz3p4g4HO/2gOv4IrpSINFNgW58S+KQtE03I2QLctYoLGw
# 8wgB3x1sTx/35zOsLmsY/Ya5QEjnSpZu3OCNwKpFN0Ng5DYeo8vnDZCmLlk4cwtx
# nkkHTht9asdpGj9r7bAYoSGWqTUFSRe1ruIUL/kCAwEAAaOCARswggEXMB0GA1Ud
# DgQWBBRuWcKtZZoKdfbJdmrf2R0AkF84XzAfBgNVHSMEGDAWgBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5j
# cmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAM
# BgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUA
# A4IBAQCmyMvLG1zMhhD05sqsYscXbpl3J6qSmpK8qeSiWG95PQXSqlO0Vxh0RJFu
# kZCKIdcAp3RDjf2dmokkpxmp9n1gjiHb6FX/kl+fyIlVwriLeEMRK6xmOnDvaWCy
# me14PW0VQcIFqDHtybWk8ZO6ATEGb0ri9KlS8IhJKIK5/PS+CLl/1qr4f5t0eDcF
# 4oho/HcCql+IVDXdvsJPvg6Vx2kA+6TRvJjv6lTsbQ4586yvZilg0/rTJQNqfu9x
# 8NW11Iuydi8hnpnlaPCUQP2QkCIh2tP/EEBfA+5fyXWhLAyKvgI9RZMySiimtf/a
# 87xG7niG48ELLfSD3jKwl28ThOE1oYIDeTCCAmECAQEwgeOhgbmkgbYwgbMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# JzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjpCMUI3LUY2N0YtRkVDMjElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIlCgEBMAkGBSsOAwIaBQAD
# FQBVVAnKu27f8CU3XsWFNgZLUA4p7aCBwjCBv6SBvDCBuTELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMe
# bkNpcGhlciBOVFMgRVNOOjRERTktMEM1RS0zRTA5MSswKQYDVQQDEyJNaWNyb3Nv
# ZnQgVGltZSBTb3VyY2UgTWFzdGVyIENsb2NrMA0GCSqGSIb3DQEBBQUAAgUA2tyR
# QzAiGA8yMDE2MDUxMDE2NTYzNVoYDzIwMTYwNTExMTY1NjM1WjB3MD0GCisGAQQB
# hFkKBAExLzAtMAoCBQDa3JFDAgEAMAoCAQACAiQxAgH/MAcCAQACAhs8MAoCBQDa
# 3eLDAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwGgCjAIAgEAAgMW
# 42ChCjAIAgEAAgMHoSAwDQYJKoZIhvcNAQEFBQADggEBACZCyHRIn2nX3L49vZkM
# 5FMhowuN9IN/dP6VGuaWw7mGKpJ57p70GRnwTivLE7PIytARll76ticDS3QCj9vd
# D8xmjOL8neDHCQsXVBpp9OwoqS23Z7LJLmvNRZmCymoL9ySRvBMEfz0MAZ9Eofje
# BXfmY22ZCfvzfZUjeJUujDtPx7pmW1BFQdh5GwOjYKhrD4fSVPXcoidfiSQ5piob
# 16ZfUF/nfyQdtPo9HPpe07ALTQrQ5HlGsnz/Dt0PnMRTcOnDDfXVgS7NqB8jC0cw
# etcvrQm++HEiubmmHuGI2KHVf3CsSi/mjcCYlmF+wYHEUvMKsVDRdW7DPNTR6EY0
# DYgxggL1MIIC8QIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAIT
# MwAAAIZc+4zodD39rwAAAAAAhjANBglghkgBZQMEAgEFAKCCATIwGgYJKoZIhvcN
# AQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCxVSzKONtYuHT6Zcos
# 1DM9IsMIQt7eAR5TV1HcnA1yWTCB4gYLKoZIhvcNAQkQAgwxgdIwgc8wgcwwgbEE
# FFVUCcq7bt/wJTdexYU2BktQDintMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTACEzMAAACGXPuM6HQ9/a8AAAAAAIYwFgQU4KFLxSrk6mgSGSfo
# 2MMUJkggVggwDQYJKoZIhvcNAQELBQAEggEAJ2qIGWYNDwlZr6o02fWJD71cbU7E
# YFl4mYDafDzlFGs4NFAPi8zvo0HvLKl62U20DyaqfUT9W7/K7RTooicgdGHZxxCr
# zcXkUkokG9uekc9G5TxYegcGsAqP2bUDvNGQycUzfDw3aAmdy3eYRgDqbZPbIrM0
# Chg5KMWKCF/hopdhrIuZiHrLCORYlty7A2w0KiupeBktPUfyIbh/CoEFVdFYNvMK
# Fdc9eYMolqk7P0qo+QIzZKgdJGqGMpaWjzg23Fd2J2wlT+kiJ/HhsFAabUp7eRcB
# lGumNV2ndWjiKKCn5RX0KP+tO89XptQ8m/gMkKxWIilOwSJRvBNMGr5m3w==
# SIG # End signature block
